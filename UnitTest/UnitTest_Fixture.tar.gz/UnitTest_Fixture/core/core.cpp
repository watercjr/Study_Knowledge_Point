#include <stdio.h>
#include <iostream>

int main()
{
    printf("Core -- Hello World!");

    return 0;
}